/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pokemonverdeneon;
import View.*;
import Classes.*;

/**
 *
 * @author danie
 */
public class PokemonVerdeNeon {
        static Welcome W;
        static Game G;

        /**
         * @param args the command line arguments
         */
        public static void main(String[] args) {
                // TODO code application logic here
                W = new Welcome();
                G = new Game();
                
               
                
        }
        
        public static void Start () {
                G.setVisible(true);
        }
        
}
